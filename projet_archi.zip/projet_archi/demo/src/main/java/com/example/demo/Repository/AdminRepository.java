package com.example.demo.Repository;


import com.example.demo.models.Admin;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

public interface AdminRepository extends JpaRepository<Admin, Long> {    
   @Query("SELECT u FROM User u WHERE u.nom = :nom")
    public Admin getUserByNom(@Param("nom") String nom);
    List<Admin> findByRole(String role);
}
