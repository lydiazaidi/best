package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.OptionRepository;
import com.example.demo.models.Options;

import java.util.List;

@Service
public class OptionService {

    @Autowired
    private OptionRepository optionRepository;

    public List<Options> findAll() {
        return optionRepository.findAll();
    }

    public void save(Options option) {
        optionRepository.save(option);
    }

    public void deleteById(Long id) {
        optionRepository.deleteById(id);
    }
}