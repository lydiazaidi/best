package com.example.demo.models;

public enum EtatCommande {
    EN_ATTENTE,
    VALIDEE,
    ANNULEE;
}
