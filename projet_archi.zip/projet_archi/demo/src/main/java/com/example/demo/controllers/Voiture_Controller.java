package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Repository.VoitureRepository;
import com.example.demo.models.Disponibilite;
import com.example.demo.models.Voiture;
import com.example.demo.services.VoitureService;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class Voiture_Controller {

@Autowired
    private VoitureRepository voitureRepository;
@Autowired
    private VoitureService voitureService;

    @GetMapping("/acceuil")
public String showAllCars(@RequestParam(value = "disponibilite", required = false) Disponibilite disponibilite,
                          @RequestParam(value = "ascending", required = false) Boolean ascending,
                          Model model) {

    List<Voiture> voitures;

    if (disponibilite != null && ascending != null) {
        // Filter by Disponibilite and sort by Prix
        Sort sort = ascending ? Sort.by(Sort.Direction.ASC, "prix") : Sort.by(Sort.Direction.DESC, "prix");
        voitures = voitureRepository.findByDisponibilite(disponibilite, sort);
    } else if (disponibilite != null) {
        // Filter by Disponibilite without sorting
        voitures = voitureRepository.findByDisponibilite(disponibilite, Sort.unsorted());
    } else if (ascending != null) {
        // Sort all cars by Prix
        Sort sort = ascending ? Sort.by(Sort.Direction.ASC, "prix") : Sort.by(Sort.Direction.DESC, "prix");
        voitures = voitureRepository.findAll(sort);
    } else {
        // No filters or sorting, fetch all cars
        voitures = voitureRepository.findAll();
    }

    // Add a message if no cars are found
    if (voitures.isEmpty()) {
        model.addAttribute("message", "No cars available at the moment.");
    }

    // Add cars and current filter/sort selections to the model
    model.addAttribute("voitures", voitures);
    model.addAttribute("selectedDisponibilite", disponibilite);
    model.addAttribute("selectedAscending", ascending);

    return "acceuil";
}

 // carinfo 
 @GetMapping("/details/{id}" )
 public String getVoitureDetails(@PathVariable Long id, Model model) {
     Voiture voiture = voitureService.getVoitureById(id);
     if (voiture == null) {
         return "errorPage"; // Handle case where car doesn't exist
     }
     model.addAttribute("voiture", voiture);
     return "info"; // Thymeleaf template for car details page (client-side view)
 }
}