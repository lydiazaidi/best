package com.example.demo.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.util.Date;
import java.util.List;

@Entity
public class Commande {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_commande;
    private Date date_commande;
    private Float montant_total;

    @Enumerated(EnumType.STRING)
    private EtatCommande etat_commande;

    @OneToMany(mappedBy = "commande", cascade = CascadeType.ALL)
    private List<Voiture> voitures; // One-to-Many avec Voiture

    @ManyToOne
    @JoinColumn(name = "carte_bancaire_id")
    private CarteBancaire carteBancaire; // Many-to-One avec CarteBancaire

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client; // Many-to-One avec Client

    public Date getDateCommande() {
        return date_commande;
    }
    public EtatCommande getEtatCommande() {
        return etat_commande;
    }
    public Long getIdCommande() {
        return id_commande;
    }
    public Float getMontantTotal() {
        return montant_total;
    }
    public void setDateCommande(Date date_commande) {
        this.date_commande = date_commande;
    }
    public void setEtatCommande(EtatCommande etat_commande) {
        this.etat_commande = etat_commande;
    }
    public void setIdCommande(Long id_commande) {
        this.id_commande = id_commande;
    }
    public void setMontantTotal(Float montant_total) {
        this.montant_total = montant_total;
    }

}