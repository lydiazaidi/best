package com.example.demo.services;

import java.util.Arrays;
import java.util.Collection;
 
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.models.Admin;
 
public class MyAdmindetails implements UserDetails {
 
    private Admin admin;
     
    public MyAdmindetails(Admin admin) {
        this.admin = admin;
    }
 
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + admin.getRole());
        return Arrays.asList(authority);
    }
 
    @Override
    public String getPassword() {
        return admin.getMotDePasse();
    }
 
    @Override
    public String getUsername() {
        return admin.getNom();
    }
 
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }
 
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }
 
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
 
    @Override
    public boolean isEnabled() {
        return true;
    }
 
}
