package com.example.demo.models;

public enum Disponibilite {
    DISPONIBLE_IMMEDIATEMENT,
    DISPONIBLE_SUR_COMMANDE,
    NON_DISPONIBLE
}
