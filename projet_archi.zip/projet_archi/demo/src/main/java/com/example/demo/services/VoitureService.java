package com.example.demo.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.VoitureRepository;
import com.example.demo.models.Disponibilite;
import com.example.demo.models.Voiture;
import org.springframework.data.domain.Sort;
import jakarta.persistence.EntityNotFoundException;


@Service
public class VoitureService {

    @Autowired
    private VoitureRepository voitureRepository;

    public List<Voiture> findAll() {
        return voitureRepository.findAll();
    }

    // Save method from JpaRepository
    public Voiture save(Voiture voiture) {
        return voitureRepository.save(voiture);
    }

    public void deleteById(Long id) {
        voitureRepository.deleteById(id);
    }

    public Voiture getVoitureById(Long id) {
        return voitureRepository.findById(id).orElse(null);
    }

    public void updateVoiture(Voiture voiture) {
        voitureRepository.save(voiture);
    }
     public Voiture findById(Long id) {
    return voitureRepository.findById(id)
        .map(voiture -> {
            // Ensure the couleurs are eagerly fetched
            voiture.getCouleurs(); // Initialize the couleurs list
            return voiture;
        })
        .orElseThrow(() -> new EntityNotFoundException("Car not found"));
}


      
    // Filter cars by Disponibilite
    public List<Voiture> filterByDisponibilite(Disponibilite disponibilite) {
        return voitureRepository.findByDisponibilite(disponibilite, Sort.unsorted());
    }

    // Sort cars by Prix
    public List<Voiture> sortByPrix(boolean ascending) {
        Sort sort = ascending ? Sort.by(Sort.Direction.ASC, "prix") : Sort.by(Sort.Direction.DESC, "prix");
        return voitureRepository.findAll(sort);
    }

    // Filter and sort cars by Disponibilite and Prix
    public List<Voiture> filterAndSortByDisponibiliteAndPrix(Disponibilite disponibilite, boolean ascending) {
        Sort sort = ascending ? Sort.by(Sort.Direction.ASC, "prix") : Sort.by(Sort.Direction.DESC, "prix");
        return voitureRepository.findByDisponibilite(disponibilite, sort);
    }


}



