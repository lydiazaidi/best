package com.example.demo.models;
import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

import java.util.Date;

@Entity
public class ReservationTest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_reservation;
    private Date date_test;
    private String etat;

     @ManyToOne
    @JoinColumn(name = "id_client")
    private Client client; // Many-to-One avec Client

     @OneToOne
    @JoinColumn(name = "voiture_id", referencedColumnName = "id_Voiture")
    private Voiture voiture; // One-to-One avec Voiture


    public Date getDateTest() {
        return date_test;
    }
    public String getEtat() {
        return etat;
    }
    public Long getIdReservation() {
        return id_reservation;
    }
    public void setDateTest(Date date_test) {
        this.date_test = date_test;
    }
    public void setEtat(String etat) {
        this.etat = etat;
    }
    public void setIdReservation(Long id_reservation) {
        this.id_reservation = id_reservation;
    }

}