package com.example.demo.services;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
/*
    @Bean
    UserDetailsService adminDetailsService() {
        return new AdminDetailsServiceImpl(); // Assuming UserDetailsServiceImpl is implemented correctly
    }*/
    public HiddenHttpMethodFilter hiddenHttpMethodFilter() {
        return new HiddenHttpMethodFilter();
    }
    @Bean
    UserDetailsService clientDetailsService() {
        return new ClientDetailsServiceImpl(); // Assuming UserDetailsServiceImpl is implemented correctly
    }

    @Bean
    BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(clientDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    	http.csrf(csrf -> csrf.disable())
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/profil","/login","signin_client","/acceuil","/voitures/details/**",
            "/update","/createVoiture","/couleurs","/options","/css/**", "/js/**", "/images/**","/uploads/**",
            "/voitures/**").permitAll() // Allow login without authentication
            .requestMatchers("/signin","/create-admin").hasRole("ADMIN") // Admin-specific routes
            .anyRequest().authenticated() // Require authentication for other routes
        )
        .formLogin(form -> form
            .loginPage("/login") 
            .defaultSuccessUrl("/acceuil", true)
            .failureUrl("/login?error") 
            .permitAll()
        )
    .logout(logout -> logout
        .logoutSuccessUrl("/login?logout") // Redirect to login after logout
        .permitAll());
return http.build();
    }

    @Bean
    AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                   .authenticationProvider(authenticationProvider())
                   .build();
 
                }

}
