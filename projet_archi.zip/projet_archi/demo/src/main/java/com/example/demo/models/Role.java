package com.example.demo.models;
public enum Role {
    AGENT_TEST,
    ADMIN,
    RESPONSABLE_MARKETING,
    AGENT_COMMERCIAL
}