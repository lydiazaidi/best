package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import com.example.demo.models.*;


import com.example.demo.Repository.*;

@Controller
public class ClientController {
    @Autowired
    private ClientRepository clientRepository;
    
    @GetMapping("/signin_client")
    public String showAddUserForm(Model model) {
        Client newUser = new Client();
        model.addAttribute("user", newUser);
        return "signin";
    }

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    @PostMapping("/signin_client")
    public String createClient(Client user ) {
        user.setMotDePasse(passwordEncoder.encode(user.getMotDePasse()));
        clientRepository.save(user);
        return "redirect:/acceuil";
    }
    @GetMapping("/login")
    public String login() {
        return "login"; // Returns login.html
    }
    @GetMapping("/profil")
    public String showProfile(Model model, Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            Client user = clientRepository.getUserByNom(username);
    
            if (user != null) {
                model.addAttribute("user", user);
            } else {
                // Handle user not found (maybe redirect to an error page)
                return "redirect:/error"; // Example redirection
            }
        } else {
            // Handle unauthenticated access, maybe redirect to login
            return "redirect:/login";
        }
    
        return "profil"; // Thymeleaf template name
    }
    
}
    

