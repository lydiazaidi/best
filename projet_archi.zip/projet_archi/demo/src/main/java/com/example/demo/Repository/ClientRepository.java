package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Client;


public interface ClientRepository extends JpaRepository<Client, Long> {

    Client findByEmail(String email);

    Client getUserByNom(String nom);
}