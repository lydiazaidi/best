package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Options;

public interface OptionRepository extends JpaRepository<Options, Long> {
    
}