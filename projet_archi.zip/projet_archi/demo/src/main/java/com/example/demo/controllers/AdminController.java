package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.models.Role;
import com.example.demo.models.Admin;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.example.demo.Repository.AdminRepository;

@Controller
public class AdminController {
    @Autowired
    private AdminRepository userRepository;

    
    // Créer un utilisateur admin 
    @GetMapping("/create-admin")
    public String createAdminUser() {
       
          Admin admin = new Admin();
            admin.setNom("sarah");
            admin.setMotDePasse(passwordEncoder.encode("sarahsarah"));
            admin.setRole(Role.ADMIN);
            userRepository.save(admin);
            return "Admin user created successfully.";
        } 
        
    
    @GetMapping("/signin")
    public String showAddUserForm(Model model) {
        Admin newUser = new Admin();
        model.addAttribute("user", newUser);
        return "signin";
    }

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    @PostMapping("/signin")
    public String createUser(Admin user) {
        user.setMotDePasse(passwordEncoder.encode(user.getMotDePasse()));
        userRepository.save(user);
        return "redirect:/acceuil";
    }
   /* @GetMapping("/login")
    public String login() {
        return "login"; // Returns login.html
    }*/
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        // Perform logout
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.logout(request, response, null);

        // Redirect to the login page after logout
        return "redirect:/login?logout";
    }


}
