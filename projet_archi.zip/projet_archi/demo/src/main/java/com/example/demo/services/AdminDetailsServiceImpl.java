package com.example.demo.services;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import com.example.demo.Repository.AdminRepository;
import com.example.demo.models.*;
 
public class AdminDetailsServiceImpl implements UserDetailsService {
 
    @Autowired
    private AdminRepository adminRepository;
     
    @Override
    public UserDetails loadUserByUsername(String nom)
            throws UsernameNotFoundException {
        Admin admin = adminRepository.getUserByNom(nom);
         
        if (admin == null) {
            throw new UsernameNotFoundException("Could not find admin");
        }
         
        return new MyAdmindetails(admin);
    }
 
}
