package com.example.demo.models;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

import java.util.Date;
import java.util.List;
@Entity
public class Voiture {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_voiture;
    private String modele;
    private Double prix;

    @Enumerated(EnumType.STRING)
    private Disponibilite disponibilite;
    private Date date_disponibilite;
    private String photo;

    @ManyToOne
    @JoinColumn(name = "commande_id")
    private Commande commande;

    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(
        name = "voiture_option",
        joinColumns = @JoinColumn(name = "voiture_id"),
        inverseJoinColumns = @JoinColumn(name = "option_id")
    )
    private List<Options> options;

    // Relation One-to-One avec Stock
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "stock_id", referencedColumnName = "id_Stock")
    private Stock stock;

     // Relation One-to-One avec ReservationTest
     @OneToOne(mappedBy = "voiture", cascade = CascadeType.ALL)
     private ReservationTest reservation;

     @OneToMany(mappedBy = "voiture", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Couleur> couleurs;
 


    public Long getIdVoiture() {
        return id_voiture;
    }

    public void setIdVoiture(Long id_voiture) {
        this.id_voiture = id_voiture;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public Double getPrix() {
        return prix;
    }

    public void setPrix(Double prix) {
        this.prix = prix;
    }

    public Disponibilite getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(Disponibilite disponibilite) {
        this.disponibilite = disponibilite;
    }

    public Date getDateDisponibilite() {
        return date_disponibilite;
    }

    public void setDateDisponibilite(Date date_disponibilite) {
        this.date_disponibilite = date_disponibilite;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setOptions(List<Options> optionsList) {
        this.options=optionsList;
    }
    public List<Options> getOptions() {
        return options;
    }


    public void setCouleurs(List<Couleur> couleursList) {
        this.couleurs=couleursList;
    }
    public List<Couleur> getCouleurs() {
        return couleurs;
    }


    
}