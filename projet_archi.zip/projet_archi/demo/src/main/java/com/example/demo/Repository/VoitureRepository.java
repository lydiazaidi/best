package com.example.demo.Repository;


import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;


import com.example.demo.models.Disponibilite;
import com.example.demo.models.Voiture;



public interface VoitureRepository extends JpaRepository<Voiture, Long> {
    
    // Find cars by Disponibilite only
    List<Voiture> findByDisponibilite(Disponibilite disponibilite, Sort sort);

    // Find all cars sorted by Prix (ascending/descending)
    List<Voiture> findAll(Sort sort);
}
