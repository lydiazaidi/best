package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Couleur;

public interface CouleurRepository extends JpaRepository<Couleur, Long>  {

}
