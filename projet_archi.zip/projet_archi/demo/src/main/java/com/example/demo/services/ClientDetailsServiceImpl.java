package com.example.demo.services;

 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import com.example.demo.Repository.*;
import com.example.demo.models.*;
 
public class ClientDetailsServiceImpl implements UserDetailsService {
 
    @Autowired
    private ClientRepository clientRepository;
     
    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {
        Client client = clientRepository.findByEmail(email);
         
        if (client == null) {
            throw new UsernameNotFoundException("Could not find client");
        }
         
        return new Myclientdetails(client);
    }
 
}
