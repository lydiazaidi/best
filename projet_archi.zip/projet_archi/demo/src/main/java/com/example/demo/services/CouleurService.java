package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.CouleurRepository;
import com.example.demo.models.Couleur;

import java.util.List;

@Service
public class CouleurService {

    @Autowired
    private CouleurRepository couleurRepository;

    public List<Couleur> findAll() {
        return couleurRepository.findAll();
    }

    public Couleur save(Couleur couleur) {
        return couleurRepository.save(couleur);
    }

    public void deleteById(Long id) {
        couleurRepository.deleteById(id);
    }
}