package com.example.demo.controllers;
/* 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.models.*;

import com.example.demo.Repository.*;

@Controller
public class UserController {

        

@Autowired
    private VoitureRepository voitureRepository;

    @GetMapping("/acceuil")
    public String showAllCars(Model model) {
    List<Voiture> voitures = voitureRepository.findAll();
    if (voitures.isEmpty()) {
        model.addAttribute("message", "No cars available at the moment.");
    }
    model.addAttribute("voitures", voitures);
    return "acceuil"; 
}}
   /* 
    @GetMapping("/signin")
    public String showAddUserForm(Model model) {
        Admin newUser = new Admin();
        model.addAttribute("user", newUser);
        return "signin";
    }

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    @PostMapping("/signin")
    public String createUser(Admin user) {
        user.setRole(Role.CLIENT);
        user.setMotDePasse(passwordEncoder.encode(user.getMotDePasse()));
        userRepository.save(user);
        return "redirect:/acceuil";
    }
    @GetMapping("/login")
    public String login() {
        return "login"; // Returns login.html
    }
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        // Perform logout
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.logout(request, response, null);

        // Redirect to the login page after logout
        return "redirect:/login?logout";
    }

   /*  @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/users";
    }
   
   @GetMapping("/create-admin")
    public String createAdminUser() {
        if (userRepository.count() == 0) {
        User admin = new User();
        admin.setUsername("sarah");
        admin.setEmail("sarah123@gmail.com");
        admin.setPassword (passwordEncoder.encode("sarahsarah"));
        admin.setRole("ADMIN");
        userRepository.save(admin);
    return "Admin user created successfully.";
     } else {
    return "Admin user already exists.";
    }
} 
 
}

*/