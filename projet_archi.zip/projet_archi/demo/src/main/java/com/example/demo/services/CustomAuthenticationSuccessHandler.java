package com.example.demo.services;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.core.Authentication;


public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        // Get the roles of the authenticated user
        var authorities = authentication.getAuthorities();

        // Check roles and redirect accordingly
        String redirectUrl = "/acceuil"; // Default for USER
        if (authorities.stream().anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"))) {
            redirectUrl = "/acceuil"; // Redirect for ADMIN
        }

        response.sendRedirect(redirectUrl);
    }
}