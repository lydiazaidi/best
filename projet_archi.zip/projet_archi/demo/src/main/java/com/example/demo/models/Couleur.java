package com.example.demo.models;
import jakarta.persistence.*;

@Entity
public class Couleur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_couleur;

    private String color_name;
    private Double prix_couleur;

    @ManyToOne
    private Voiture voiture;

    public Long getId() {
        return id_couleur;
    }

    public String getColor_name() {
        return color_name;
    }

    public void setColor_name(String color_name) {
        this.color_name = color_name;
    }

    public Double getPrix_couleur() {
        return prix_couleur;
    }

    public void setPrix_couleur(Double prix_couleur) {
        this.prix_couleur = prix_couleur;
    }

    public Voiture getVoiture() {
        return voiture;
    }

    public void setVoiture(Voiture voiture) {
        this.voiture = voiture;
    }
}