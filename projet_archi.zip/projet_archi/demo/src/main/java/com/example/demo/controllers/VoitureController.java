package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.Repository.VoitureRepository;
import com.example.demo.models.Couleur;
import com.example.demo.models.Disponibilite;
import com.example.demo.models.Options;
import com.example.demo.models.Voiture;
import com.example.demo.services.CouleurService;
import com.example.demo.services.OptionService;
import com.example.demo.services.VoitureService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping("/voitures")
public class VoitureController {

    @Autowired
    private VoitureService voitureService;

    @Autowired
    private CouleurService couleurService;

    @Autowired
private OptionService optionService;

@Autowired
    private VoitureRepository voitureRepository;

    @GetMapping
    public String listVoitures(Model model) {
        List<Voiture> voitures = voitureRepository.findAll();
        System.out.println("Nombre de voitures récupérées : " + voitures.size());
        voitures.forEach(voiture -> System.out.println(voiture));
        model.addAttribute("voitures", voitures);
        return "voiture";
    }

    @GetMapping("/createVoiture")
    public String addVoitureForm(Model model) {
        model.addAttribute("voiture", new Voiture());
        return "voitures/createVoiture";
    }
    @PostMapping("/createVoiture")
    public String createVoiture(
        @RequestParam String modele,
        @RequestParam Double prix,
        @RequestParam String disponibilite,
        @RequestParam(required = false) String date_disponibilite,
        @RequestParam("photo") MultipartFile photo,  // Handle the photo as MultipartFile
        @RequestParam List<String> optionDescriptions,
        @RequestParam List<Double> optionPrices,
        @RequestParam List<String> colorNames,
        @RequestParam List<Double> colorPrices,
        RedirectAttributes redirectAttributes
    ) {
        // Process the photo
        String photoPath = saveUploadedFile(photo);
    
        Voiture voiture = new Voiture();
        voiture.setModele(modele);
        voiture.setPrix(prix);
        voiture.setDisponibilite(Disponibilite.valueOf(disponibilite));
        if (date_disponibilite != null && !date_disponibilite.isEmpty()) {
            LocalDate localDate = LocalDate.parse(date_disponibilite);
            Date date = Date.valueOf(localDate);
            voiture.setDateDisponibilite(date);
        }
        voiture.setPhoto(photoPath);  // Save the file path to the database
    
        // Process options and associate them with voiture
        List<Options> optionsList = new ArrayList<>();
        for (int i = 0; i < optionDescriptions.size(); i++) {
            Options option = new Options();
            option.setDescription(optionDescriptions.get(i));
            option.setPrix(optionPrices.get(i).floatValue());
    
            // Save the option before adding it to voiture
            optionsList.add(option);
            optionService.save(option); // Save the option entity to the database
        }
        voiture.setOptions(optionsList);  // Set options in voiture
    
        // Save voiture (this will also persist options due to cascade)
        voitureService.save(voiture);
    
        // Process colors and associate them with voiture
        List<Couleur> couleursList = new ArrayList<>();
        for (int i = 0; i < colorNames.size(); i++) {
            Couleur couleur = new Couleur();
            couleur.setColor_name(colorNames.get(i));
            couleur.setPrix_couleur(colorPrices.get(i));
            couleur.setVoiture(voiture);  // Associate the saved voiture with the couleur
            couleurService.save(couleur);
            couleursList.add(couleur);
        }
        voiture.setCouleurs(couleursList);  // Set colors in voiture
    
        redirectAttributes.addFlashAttribute("message", "Voiture ajoutée avec succès!");
        return "redirect:/voitures";
    }

    private String saveUploadedFile(MultipartFile file) {
            try {
                if (file.isEmpty()) {
                    throw new IOException("File is empty.");
                }
    
                Path uploadDirectory = Paths.get("demo\\src\\main\\resources\\static\\images");
                if (!Files.exists(uploadDirectory)) {
                    Files.createDirectories(uploadDirectory);
                }
    
                String fileName = file.getOriginalFilename();
                Path destinationPath = uploadDirectory.resolve(fileName);
    
                Files.copy(file.getInputStream(), destinationPath, StandardCopyOption.REPLACE_EXISTING);
    
                return "images/" + fileName;  // Save the relative path to the database
    
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to store file: " + e.getMessage());
            }
    }
    
    
   
    @GetMapping("/{id}")
    public String deleteVoiture(@PathVariable Long id) {
        voitureService.deleteById(id);
        return "redirect:/voitures";
    }

    @PostMapping("/update")
    public String updateVoiture(@ModelAttribute Voiture voiture) {
        if (voiture.getIdVoiture() != null) {
            // Récupérer l'objet Voiture existant depuis la base de données
            Voiture existingVoiture = voitureRepository.findById(voiture.getIdVoiture())
                    .orElseThrow(() -> new IllegalArgumentException("Invalid voiture ID: " + voiture.getIdVoiture()));
    
            // Mettre à jour les champs de la voiture existante
            existingVoiture.setModele(voiture.getModele());
            existingVoiture.setPrix(voiture.getPrix());
            existingVoiture.setDisponibilite(voiture.getDisponibilite());
            existingVoiture.setDateDisponibilite(voiture.getDateDisponibilite());
            existingVoiture.setPhoto(voiture.getPhoto());
    
            // Sauvegarder les modifications
            voitureRepository.saveAndFlush(existingVoiture);
        }
        return "redirect:/voitures";  // Rediriger vers la page des voitures
    }

    @GetMapping("/update/{id}")
    public String showUpdateForm(@PathVariable Long id, Model model) {
        Voiture voiture = voitureService.getVoitureById(id);
        model.addAttribute("voiture", voiture);
        return "edit_voiture";
    }
}