package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.CarteBancaire;

public interface CarteBancaireRepository extends JpaRepository<CarteBancaire, String> {
    
}